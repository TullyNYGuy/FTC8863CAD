                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3172927
Moto E4 Phone Mount. Beefed Design. by VCHSRobotics is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Moto E4 Based Phone Mount. Beefed up design inspired by ServoCity/Actobotics and Cheer4ftc designs. Top and Bottom Clips are compatible with Cheer4FTC Bases. 

https://www.thingiverse.com/thing:3013147
https://www.thingiverse.com/thing:3013142

Mount comes in two choices. 3 Piece set, or 1 piece. The 3-piece set clicks together like the stated above kits, and allows for replacement pieces to quickly be switched out, instead of the whole mount if 1 part was to get damaged.

Mount allows Moto E4 to click in, or slid in, but should be slid out the top of the mount afterwords. Mount is a beefed up version, while allowing access to the buttons of the E4. Top Clip, or top part of the mount is already rounded out so buttons will not be hit by the mount itself. Offers support to the bottom of the phone, and optional Ziptie-able USB holes. 

Hole Pattern is both Tetrix and Actobotics.